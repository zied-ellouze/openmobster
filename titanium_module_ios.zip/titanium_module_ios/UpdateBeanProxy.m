//
//  UpdateBeanProxy.m
//  titanium_module_ios
//
//  Created by openmobster on 6/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "UpdateBeanProxy.h"
#import "TitaniumKernel.h"
#import "MobileBean.h"


@implementation UpdateBeanProxy

@synthesize bean;

+(UpdateBeanProxy *) withInit
{
	UpdateBeanProxy *instance = [[UpdateBeanProxy alloc] init];
	instance = [instance autorelease];
	return instance;
}

-(void) dealloc
{	
	if(self.bean != nil)
	{
		[self.bean release];
	}
	[super dealloc];
}

-(id) oid:(id)input
{
	if(self.bean == nil)
	{
		return nil;
	}
	
	return [self.bean getId];
}

-(id) getValue:(id)input
{	
	NSArray *parameters = (NSArray *)input;
	
	NSString *fieldUri = [parameters objectAtIndex:0];
	
	//Validate the input
	if(fieldUri == nil)
	{
		return nil;
	}
	
	if(self.bean == nil)
	{
		//Not Found
		return nil;
	}
	
	NSString *value = [self.bean getValue:fieldUri];
	
	return value;
}

-(void) setValue:(id)input
{	
	NSArray *parameters = (NSArray *)input;
	
	NSString *fieldUri = [parameters objectAtIndex:0];
	NSString *value = [parameters objectAtIndex:1];
	
	//Validate the input
	if(fieldUri == nil || value == nil)
	{
		return;
	}
	
	if(self.bean == nil)
	{
		return;
	}
	
	[self.bean setValue:fieldUri :value];
}

-(void) commit:(id) input
{	
	if(self.bean == nil)
	{
		return;
	}
	
	[self.bean save];
}

-(id) arrayLength:(id)input
{	
	NSArray *parameters = (NSArray *)input;
	
	NSString *arrayUri = [parameters objectAtIndex:0];
	
	//Validate the input
	if(arrayUri == nil)
	{
		return nil;
	}
	
	if(self.bean == nil)
	{
		return nil;
	}
	
	BeanList *array = [self.bean readList:arrayUri];
	if(array == nil)
	{
		return nil;
	}
	
	int arraySize = [array size];
	
	return [NSNumber numberWithInt:arraySize];
}
@end