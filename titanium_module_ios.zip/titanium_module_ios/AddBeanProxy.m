/**
 * Appcelerator Titanium Mobile
 * Copyright (c) 2009-2011 by Appcelerator, Inc. All Rights Reserved.
 * Licensed under the terms of the Apache Public License
 * Please see the LICENSE included with this distribution for details.
 */

#import "AddBeanProxy.h"

#import "TiUtils.h"

@implementation AddBeanProxy

@synthesize bean;

+(AddBeanProxy *) withInit
{
	AddBeanProxy *instance = [[AddBeanProxy alloc] init];
	instance = [instance autorelease];
	return instance;
}

-(void) dealloc
{
	if(self.bean != nil)
	{
		[self.bean release];
	}
	[super dealloc];
}

-(id) oid:(id)input
{
	if(self.bean == nil)
	{
		return nil;
	}
	
	return [self.bean getId];
}

-(id) getValue:(id)input
{	
	NSArray *parameters = (NSArray *)input;
	
	NSString *fieldUri = [parameters objectAtIndex:0];
	
	//Validate the input
	if(fieldUri == nil)
	{
		return nil;
	}
	
	if(self.bean == nil)
	{
		//Not Found
		return nil;
	}
	
	NSString *value = [self.bean getValue:fieldUri];
	
	return value;
}


-(void) setValue:(id)input
{	
	NSArray *parameters = (NSArray *)input;
	
	NSString *fieldUri = [parameters objectAtIndex:0];
	NSString *value = [parameters objectAtIndex:1];
	
	//Validate the input
	if(fieldUri == nil || value == nil)
	{
		return;
	}
	
	//Get the bean to be updated
	if(self.bean == nil)
	{
		return;
	}
	
	[self.bean setValue:fieldUri :value];
}

-(id) commit:(id) input
{	
	if(self.bean == nil)
	{
		return nil;
	}
	
	[self.bean save];
	
	NSString *id = [self.bean getId];
	
	return id;
}
@end
